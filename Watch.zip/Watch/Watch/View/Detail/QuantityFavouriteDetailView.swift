//
//  QuantityFavouriteDetailView.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-16.
//

import SwiftUI

struct QuantityFavouriteDetailView: View {
    // MARK: - PROPERTY
    
    @Binding var quantity: Int
    @EnvironmentObject var shop: Shop
    @State private var isFavorite: Bool = false
    
    // MARK: - BODY
    
    var body: some View {
        HStack(alignment: .center, spacing: 6, content: {
            Button(action: {
                if quantity > 1 {
                    feedback.impactOccurred()
                    quantity -= 1
                }
            }, label: {
                Image(systemName: "minus.circle")
            })
            
            Text("\(quantity)")
                .fontWeight(.semibold)
                .frame(minWidth: 36)
            
            Button(action: {
                if quantity < 10 {
                    feedback.impactOccurred()
                    quantity += 1
                }
            }, label: {
                Image(systemName: "plus.circle")
            })
            
            Spacer()
            
            Button(action: {
                feedback.impactOccurred()
                isFavorite.toggle()
            }, label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .foregroundColor(.pink)
            })
        }) //: HSTACK
        .font(.system(.title, design: .rounded))
        .foregroundColor(.black)
        .imageScale(.large)
    }
}

// MARK: - PREVIEW

struct QuantityFavouriteDetailView_Previews: PreviewProvider {
    static var previews: some View {
        QuantityFavouriteDetailView(quantity: .constant(1))
            .environmentObject(Shop())
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
