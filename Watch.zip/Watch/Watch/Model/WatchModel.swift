//
//  WatchModel.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-16.
//

import Foundation
import SwiftUI

struct Watch: Codable, Identifiable, Equatable {
    let id: Int
    let name: String
    let image: String
    let price: Int
    let description: String
    let color: [Double]
    let features: [String]
    let category: String
    let availableSizes: [String]
    
    // Computed properties
    var red: Double { return color[0] }
    var green: Double { return color[1] }
    var blue: Double { return color[2] }
    
    var formattedPrice: String { return "$\(price)" }
    
    // Add Equatable conformance to allow using "contains" on arrays of Watch
    static func == (lhs: Watch, rhs: Watch) -> Bool {
        return lhs.id == rhs.id
    }
    
    // Helper function to get color for UI
    func getColor() -> Color {
        return Color(red: red, green: green, blue: blue)
    }
    
    // For backwards compatibility with existing JSON data
    // This initializer handles JSON files that don't have category and availableSizes fields
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        image = try container.decode(String.self, forKey: .image)
        price = try container.decode(Int.self, forKey: .price)
        description = try container.decode(String.self, forKey: .description)
        color = try container.decode([Double].self, forKey: .color)
        features = try container.decode([String].self, forKey: .features)
        
        // Set default values for new fields if they don't exist in JSON
        if container.contains(.category) {
            category = try container.decode(String.self, forKey: .category)
        } else {
            // Default category based on name
            if name.lowercased().contains("men") || name.lowercased().contains("male") {
                category = "Male"
            } else if name.lowercased().contains("women") || name.lowercased().contains("female") {
                category = "Female"
            } else if name.lowercased().contains("kid") || name.lowercased().contains("child") {
                category = "Kids"
            } else if name.lowercased().contains("strap") || name.lowercased().contains("band") {
                category = "Accessories"
            } else {
                category = "Male"  // Default to Male if unspecified
            }
        }
        
        if container.contains(.availableSizes) {
            availableSizes = try container.decode([String].self, forKey: .availableSizes)
        } else {
            // Default sizes
            if category == "Accessories" {
                availableSizes = ["S", "M", "L"]
            } else if category == "Kids" {
                availableSizes = ["XS", "S", "M"]
            } else {
                availableSizes = ["S", "M", "L", "XL"]
            }
        }
    }
    
    enum CodingKeys: String, CodingKey {
        case id, name, image, price, description, color, features, category, availableSizes
    }
}
