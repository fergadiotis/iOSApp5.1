//
//  RatingsSizeDetailView.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-21.
//

import SwiftUI

struct RatingsSizeDetailView: View {
    // MARK: - PROPERTY
    
    @Binding var selectedSize: String
    let sizes: [String] = ["XS", "S", "M", "L", "XL"]
    
    // MARK: - BODY
    
    var body: some View {
        VStack(spacing: 10) {
            // SECTION TITLES
            HStack {
                Text("Ratings")
                    .font(.footnote)
                    .fontWeight(.semibold)
                Spacer()
                Text("Sizes")
                    .font(.footnote)
                    .fontWeight(.semibold)
            }
            
            // RATINGS AND SIZES
            HStack(alignment: .center, spacing: 3) {
                // RATINGS STARS
                HStack(spacing: 5) {
                    ForEach(1...5, id: \.self) { _ in
                        Image(systemName: "star")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 15, height: 15)
                            .foregroundColor(.gray.opacity(0.5))
                    }
                }
                
                Spacer()
                
                // SIZES BUTTONS
                HStack(spacing: 5) {
                    ForEach(sizes, id: \.self) { size in
                        Button(action: {
                            selectedSize = size
                        }) {
                            Text(size)
                                .font(.footnote)
                                .fontWeight(.heavy)
                                .foregroundColor(selectedSize == size ? .white : .gray)
                                .frame(width: 28, height: 28)
                                .background(
                                    ZStack {
                                        if selectedSize == size {
                                            RoundedRectangle(cornerRadius: 5)
                                                .fill(Color.gray)
                                        }
                                        RoundedRectangle(cornerRadius: 5)
                                            .stroke(Color.gray, lineWidth: 1)
                                    }
                                )
                        }
                    }
                }
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
    }
}

// MARK: - PREVIEW

struct RatingsSizeDetailView_Previews: PreviewProvider {
    static var previews: some View {
        RatingsSizeDetailView(selectedSize: .constant("M"))
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
