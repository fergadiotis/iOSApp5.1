//
//  AddToCartDetailView.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-16.
//

import SwiftUI

struct AddToCartDetailView: View {
    // MARK: - PROPERTY
    
    @EnvironmentObject var shop: Shop
    @State private var showingAlert: Bool = false
    @Binding var quantity: Int
    @Binding var selectedSize: String
    
    // MARK: - BODY
    
    var body: some View {
        Button(action: {
            feedback.impactOccurred()
            
            // Add to cart only if a product is selected
            if let product = shop.selectedProduct {
                shop.addToCart(product, quantity: quantity, size: selectedSize)
                showingAlert = true
            }
        }, label: {
            Spacer()
            Text("Add to cart".uppercased())
                .font(.system(.title2, design: .rounded))
                .fontWeight(.bold)
                .foregroundColor(.white)
            Spacer()
        }) //: BUTTON
        .padding(15)
        .background(
            Color(
                red: shop.selectedProduct?.red ?? sampleWatch.red,
                green: shop.selectedProduct?.green ?? sampleWatch.green,
                blue: shop.selectedProduct?.blue ?? sampleWatch.blue
            )
        )
        .clipShape(Capsule())
        .alert(isPresented: $showingAlert) {
            Alert(
                title: Text("Added to Cart"),
                message: Text("\(quantity) x \(shop.selectedProduct?.name ?? "Watch") (Size: \(selectedSize)) added to your cart."),
                dismissButton: .default(Text("Continue Shopping"))
            )
        }
    }
}

// MARK: - PREVIEW

struct AddToCartDetailView_Previews: PreviewProvider {
    static var previews: some View {
        AddToCartDetailView(quantity: .constant(1), selectedSize: .constant("M"))
            .environmentObject(Shop())
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
