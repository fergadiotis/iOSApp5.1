//
//  CartView.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-21.
//

import SwiftUI

struct CartView: View {
    // MARK: - PROPERTIES
    
    @EnvironmentObject var shop: Shop
    @Environment(\.presentationMode) var presentationMode
    
    // MARK: - BODY
    
    var body: some View {
        NavigationView {
            VStack {
                if shop.cart.isEmpty {
                    EmptyCartView()
                } else {
                    FilledCartView()
                }
            }
            .navigationTitle("Shopping Cart")
            .navigationBarItems(
                leading: Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.title2)
                },
                trailing: shop.cart.isEmpty ? nil : EditButton()
            )
        }
    }
}

// MARK: - EMPTY CART VIEW

struct EmptyCartView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "cart")
                .font(.system(size: 60))
                .foregroundColor(.gray)
                .padding(.top, 50)
            
            Text("Your cart is empty")
                .font(.title)
                .fontWeight(.medium)
                .foregroundColor(.gray)
            
            Text("Start adding some beautiful watches!")
                .font(.body)
                .foregroundColor(.gray)
            
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Text("Continue Shopping")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding(.top, 20)
            
            Spacer()
        }
    }
}

// MARK: - FILLED CART VIEW

struct FilledCartView: View {
    @EnvironmentObject var shop: Shop
    @Environment(\.presentationMode) var presentationMode
    @State private var isShowingCheckout: Bool = false
    
    var body: some View {
        List {
            ForEach(shop.cart) { item in
                CartItemRow(item: item)
            }
            .onDelete(perform: removeItems)
        }
        
        VStack(spacing: 20) {
            Divider()
            
            HStack {
                Text("Total:")
                    .font(.title3)
                    .fontWeight(.bold)
                
                Spacer()
                
                Text("$\(shop.cartTotal())")
                    .font(.title3)
                    .fontWeight(.bold)
            }
            .padding(.horizontal)
            
            Button(action: {
                isShowingCheckout = true
            }) {
                Text("CHECKOUT")
                    .font(.headline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
            .alert(isPresented: $isShowingCheckout) {
                Alert(
                    title: Text("Order Confirmed"),
                    message: Text("Your order has been placed successfully. Thank you for shopping with us!"),
                    dismissButton: .default(Text("OK")) {
                        // Clear the cart and dismiss the view
                        shop.clearCart()
                        presentationMode.wrappedValue.dismiss()
                    }
                )
            }
        }
    }
    
    // Remove items at specified indices
    private func removeItems(at offsets: IndexSet) {
        for index in offsets.sorted(by: >) {
            shop.removeFromCart(at: index)
        }
    }
}

// MARK: - PREVIEW

struct CartView_Previews: PreviewProvider {
    static var previews: some View {
        CartView()
            .environmentObject(Shop())
    }
}
