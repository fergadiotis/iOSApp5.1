//
//  NavigationBarDetailView.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-16.
//

import SwiftUI

struct NavigationBarDetailView: View {
  // MARK: - PROPERTY
  
  @EnvironmentObject var shop: Shop
  @State private var isShowingCart: Bool = false
    
  // MARK: - BODY
  
  var body: some View {
    HStack {
      Button(action: {
        withAnimation(.easeIn) {
          feedback.impactOccurred()
          shop.selectedProduct = nil
          shop.showingProduct = false
        }
      }, label: {
        Image(systemName: "chevron.left")
          .font(.title)
          .foregroundColor(.white)
      })
      
      Spacer()
      
      Button(action: {
        feedback.impactOccurred()
        isShowingCart = true
      }, label: {
        ZStack {
          Image(systemName: "cart")
            .font(.title)
            .foregroundColor(.white)
            
          if !shop.cart.isEmpty {
            Circle()
              .fill(Color.red)
              .frame(width: 14, height: 14, alignment: .center)
              .offset(x: 13, y: -10)
          }
        }
      })
      .sheet(isPresented: $isShowingCart) {
        CartView()
          .environmentObject(shop)
      }
    } //: HSTACK
  }
}
