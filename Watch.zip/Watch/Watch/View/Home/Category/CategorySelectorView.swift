//
//  CategorySelectorView.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-21.
//

import SwiftUI

struct CategorySelectorView: View {
    // MARK: - PROPERTIES
    
    @EnvironmentObject var shop: Shop
    
    // MARK: - BODY
    
    var body: some View {
        HStack {
            ForEach(WatchCategory.allCases, id: \.self) { category in
                CategoryButton(category: category)
            }
        }
        .padding(.horizontal)
        .padding(.top, 10)
        .padding(.bottom, 15)
        .background(Color.white)
    }
}

struct CategoryButton: View {
    // MARK: - PROPERTIES
    
    let category: WatchCategory
    @EnvironmentObject var shop: Shop
    
    // MARK: - BODY
    
    var body: some View {
        Button(action: {
            shop.selectedCategory = category
            feedback.impactOccurred()
        }) {
            Text(category.displayName)
                .font(.system(.footnote, design: .rounded))
                .fontWeight(shop.selectedCategory == category ? .bold : .medium)
                .foregroundColor(shop.selectedCategory == category ? .white : .gray)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(
                    shop.selectedCategory == category ?
                        Color.blue :
                        Color.gray.opacity(0.2)
                )
                .cornerRadius(12)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - PREVIEW

struct CategorySelectorView_Previews: PreviewProvider {
    static var previews: some View {
        CategorySelectorView()
            .environmentObject(Shop())
            .previewLayout(.sizeThatFits)
            .padding()
            .background(Color.gray.opacity(0.2))
    }
}
