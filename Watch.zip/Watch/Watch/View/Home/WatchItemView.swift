//
//  WatchItemView.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-16.
//

import SwiftUI

// Proper structure for WatchItemView
struct WatchItemView: View {
    // MARK: - PROPERTY
    
    let watch: Watch
    
    // Get the correct image name
    private var imageName: String {
        // For accessories
        if watch.category == "Accessories" {
            switch watch.name {
            case "Mesh Bracelet":
                return "Mesh-bracelet"
            case "Premium Leather Band", "Premium Band":
                return "Premium-band"
            case "Silicon Sport Band", "Silicon Band":
                return "Silicon-band"
            default:
                return watch.image
            }
        }
        
        // For watches
        switch watch.name {
        case "Active Fitness":
            return "Active-fitness"
        case "Elegant Rose Gold":
            return "Elegant-Rose-Gold"
        case "Junior Digital":
            return "Junior-digital"
        case "Kids Explorer":
            return "Kids-explorer"
        case "Petite Pearl":
            return "Petite-Pearl"
        case "Smart Digital":
            return "watch-smart-digital"
        case "Classic Silver":
            return "watch-classic-silver"
        case "Luxury Gold":
            return "watch-luxury-gold"
        case "Sport Black":
            return "watch-sport-black"
        case "Casual Brown":
            return "watch-casual-brown"
        case "Vintage Leather":
            return "watch-vintage-leather"
        default:
            return watch.image
        }
    }
    
    // MARK: - BODY
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            // IMAGE
            ZStack {
                // Try a system image to verify the view is working
                Image(systemName: "clock.fill")
                    .resizable()
                    .scaledToFit()
                    .padding(10)
                    .foregroundColor(.blue)
                    .opacity(0.2) // Semi-transparent
                
                // Actual product image
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .padding(10)
            }
            .background(Color.white)
            .cornerRadius(20)
            
            // NAME
            Text(watch.name)
                .font(.title3)
                .fontWeight(.black)
            
            // PRICE
            Text(watch.formattedPrice)
                .fontWeight(.semibold)
                .foregroundColor(.gray)
        }
        .padding(17)
        .onAppear {
            // Print debugging information
            print("Loading WatchItemView for: \(watch.name)")
            print("Category: \(watch.category)")
            print("Image path being used: \(imageName)")
        }
    }
}
