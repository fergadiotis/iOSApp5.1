//
//  Shop.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-16.
//

import Foundation
import SwiftUI

// Watch category enum
enum WatchCategory: String, CaseIterable {
    case all = "All"
    case male = "Male"
    case female = "Female"
    case kids = "Kids"
    case accessories = "Accessories"
    
    var displayName: String {
        return self.rawValue
    }
}

// Cart item model
struct CartItem: Identifiable {
    let id = UUID()
    let watch: Watch
    var quantity: Int
    let size: String
}

// This is the main Shop class that will be used as an environment object
class Shop: ObservableObject {
    // Published properties to track state
    @Published var showingProduct: Bool = false
    @Published var selectedProduct: Watch? = nil
    @Published var selectedCategory: WatchCategory = .all
    
    // Cart functionality
    @Published var cart: [CartItem] = []
    
    // Method to add a watch to the cart
    func addToCart(_ watch: Watch, quantity: Int = 1, size: String = "M") {
        // Check if this exact item (same watch + same size) is already in cart
        if let index = cart.firstIndex(where: { $0.watch.id == watch.id && $0.size == size }) {
            // Update quantity of existing item
            cart[index].quantity += quantity
        } else {
            // Add as new item
            let newItem = CartItem(watch: watch, quantity: quantity, size: size)
            cart.append(newItem)
        }
    }
    
    // Method to remove a specific cart item
    func removeFromCart(at index: Int) {
        guard index < cart.count else { return }
        cart.remove(at: index)
    }
    
    // Method to clear the cart
    func clearCart() {
        cart = []
    }
    
    // Calculate total cart value
    func cartTotal() -> Int {
        return cart.reduce(0) { $0 + ($1.watch.price * $1.quantity) }
    }
    
    // Get watches filtered by category
    func getFilteredWatches() -> [Watch] {
        if selectedCategory == .all {
            return watches
        } else {
            return watches.filter { $0.category == selectedCategory.rawValue }
        }
    }
    
}
