//
//  CartItemRow.swift
//  Watch
//
//  Created by Tassos Fergadiotis on 2025-03-21.
//

import SwiftUI

// MARK: - CART ITEM ROW

struct CartItemRow: View {
    let item: CartItem
    
    // Get the correct image name
    private var imageName: String {
        // Handle accessories which are in their own folder
        if item.watch.category == "Accessories" {
            return "Accessories/\(item.watch.image)"
        }
        
        // For all other watches (including Female and Kids)
        return item.watch.image
    }
    
    var body: some View {
        HStack(spacing: 15) {
            // Use computed image name
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 60, height: 60)
                .cornerRadius(10)
                .background(
                    Color(
                        red: item.watch.red,
                        green: item.watch.green,
                        blue: item.watch.blue
                    )
                )
                .cornerRadius(10)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(item.watch.name)
                    .font(.headline)
                
                Text("Size: \(item.size)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                HStack {
                    Spacer()
                    
                    Text("Qty: \(item.quantity)")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                
                Text("$\(item.watch.price * item.quantity)")
                    .font(.subheadline)
                    .fontWeight(.semibold)
            }
            
            Spacer()
        }
        .padding(.vertical, 4)
    }
}

// MARK: - PREVIEW

struct CartItemRow_Previews: PreviewProvider {
    static var previews: some View {
        let sampleItem = CartItem(
            watch: sampleWatch,
            quantity: 2,
            size: "M"
        )
        
        CartItemRow(item: sampleItem)
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
